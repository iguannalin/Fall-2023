#pragma once

#include "ofxTCPClient.h"
#include "ofxTCPManager.h"
#include "ofxTCPServer.h"
#include "ofxUDPManager.h"
